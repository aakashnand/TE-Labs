package mypackage;

import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;

public  class Buffer {

	char buffer [] =new char[40];
	int type;
	/*Queue<PCB> ifb = new ArrayBlockingQueue<>(10);
	Queue<PCB> eb = new ArrayBlockingQueue<>(10);
	Queue<PCB> ofb = new ArrayBlockingQueue<>(10);
	Queue<PCB> loadQ = new ArrayBlockingQueue<>(10);
	Queue<PCB> readyQ = new ArrayBlockingQueue<>(10);
	Queue<PCB> terminateQ = new ArrayBlockingQueue<>(10);*/

}
